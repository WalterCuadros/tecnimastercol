Se crea la columna id_tipo_aparato en aparatos
new tabla municipío
nuevos campos en la tabla servicios: valor_tecnico, valor_tecnimaster