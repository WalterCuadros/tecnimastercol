    <?php $this->load->view("common/public/head"); ?>
  </head>
  <body id="blog" data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
    <div class="site-wrap">
      <div itemscope itemtype = "http://schema.org/LocalBusiness" >

        <?php $this->load->view("common/public/navbar")?>

        <div class="intro-section site-blocks-cover innerpage" style="background-image: url('<?php echo base_url(); ?>assets/img/web/header_blog.png');">
          <div class="container">
            <div class="row align-items-center text-center">
              <div class="col-lg-12 text-center" data-aos="fade-up">
                <h3>TecniMasterCol</h3>
                <p class="text-white">Más cerca de tu hogar</p>
              </div>
            </div>
          </div>
        </div>
        <!-- END slider --> 

        <div class="site-section">
          <div class="container">
            <div class="row">
              <div class="col-md-6 mb-5 mb-lg-5 col-lg-4">
                <div class="card">
                  <div class="card-header p-0">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/por-que-realizar-el-mantenimiento.html" class="img-link">
                      <img src="<?php echo base_url(); ?>assets/img/web/blog_lavadora.jpeg" alt="Image" class="img-fluid w-100">
                    </a>
                  </div>
                  <div class="card-body">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/por-que-realizar-el-mantenimiento.html">
                      <h5>¿Por qué realizar el mantenimiento preventivo a tu lavadora, nevera y aire acondicionado?</h5>
                    </a>
                    <div class="meta">blog TECNIMASTER</div>
                  </div>
                  <div class="card-footer">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/por-que-realizar-el-mantenimiento.html">LEER TODO</a>
                  </div>
                </div>
              </div>
              <div class="col-md-6 mb-5 mb-lg-5 col-lg-4">
                <div class="card">
                  <div class="card-header p-0">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html" class="img-link">
                      <img src="<?php echo base_url(); ?>assets/img/web/tarjeta.jpeg" alt="Image" class="img-fluid w-100">
                    </a>
                  </div>
                  <div class="card-body">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html">
                      <h5>¿Que es Tecnimaster?</h5>
                    </a>                    
                    <div class="meta">blog TECNIMASTER</div>
                  </div>
                  <div class="card-footer">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html">LEER TODO</a>
                  </div>
                </div>
              </div>
              <div class="col-md-6 mb-5 mb-lg-5 col-lg-4">
                <div class="card">
                  <div class="card-header p-0">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html" class="img-link">
                      <img src="<?php echo base_url(); ?>assets/img/web/blog_lavadora2.jpeg" alt="Image" class="img-fluid w-100">
                    </a>
                  </div>
                  <div class="card-body">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html">
                      <h5>Nuevas tecnologías en lavadoras</h5>
                    </a>                    
                    <div class="meta">blog TECNIMASTER</div>
                  </div>
                  <div class="card-footer">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html">LEER TODO</a>
                  </div>
                </div>
              </div>
              <div class="col-md-6 mb-5 mb-lg-5 col-lg-4">
                <div class="card">
                  <div class="card-header p-0">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html" class="img-link">
                      <img src="<?php echo base_url(); ?>assets/img/web/blog_nevera .jpeg" alt="Image" class="img-fluid w-100">
                    </a>
                  </div>
                  <div class="card-body">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html">
                      <h5>¿Ya le mandaste hacer mantenimiento a tu nevera?</h5>
                    </a>                    
                    <div class="meta">blog TECNIMASTER</div>
                  </div>
                  <div class="card-footer">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html">LEER TODO</a>
                  </div>
                </div>
              </div>
              <div class="col-md-6 mb-5 mb-lg-5 col-lg-4">
                <div class="card">
                  <div class="card-header p-0">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html" class="img-link">
                      <img src="<?php echo base_url(); ?>assets/img/web/blog_nevera1.jpeg" alt="Image" class="img-fluid w-100">
                    </a>
                  </div>
                  <div class="card-body">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html">
                      <h5>Tips para el cuidado de tu nevera </h5>
                    </a>
                    <div class="meta">blog TECNIMASTER</div>
                  </div>
                  <div class="card-footer">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/blog-post.html">LEER TODO</a>
                  </div>
                </div>
              </div>
              <div class="col-md-6 mb-5 mb-lg-5 col-lg-4">
                <div class="card">
                  <div class="card-header p-0">
                    <iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2F1239481806177411%2Fvideos%2F725751037936640%2F&show_text=0&width=560" width="100%" height="100%" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true"></iframe>
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/11/por-que-realizar-el-mantenimiento.html" class="img-link"></a>
                  </div>
                  <div class="card-body">
                    <a href="https://tecnimasterbucaramanga.blogspot.com/2019/12/somos-talento-tecno-parque-sena.html">
                      <h5>Somos talento Tecnoparque SENA <br> Lo que viene a futuro</h5>
                    </a>
                    <div class="meta">blog TECNIMASTER</div>
                  </div>
                </div>
              </div>                
            </div>
          </div>
        </div>

        <!-- <div class="py-5 bg-primary block-12 ">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg-12" style="text-align: center;">
                <a href="<?php echo base_url().'welcome/index'?>#servicios"><h3 class="text-white">Conoce nuestros precios y agenda tu servicio AQUI</h3></a>
              </div>
            </div>
          </div>
        </div> -->

        <div id="promociones_box">
        <div class="container pt-5">
          <div class="row">
            <div class="col-12 text-center">
              <h3 class="label-white">Regístrate y gana Descuentos</h3>
              <p class="label-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
              <button class="btn btn-primary my-4" data-toggle="modal" data-target="#registrarmeModal">Registrarme</button>
            </div>
          </div>
        </div>
      </div>
    
    <!-- END block-2 -->
    <?php  
    if (count($promocion)>0) {
      $this->load->view("common/public/modal_promociones");
    }else{
      $this->load->view("common/public/modal_registro");
    }
    $this->load->view("common/public/modal_servicio");
    $this->load->view("common/public/footer");
    $this->load->view("common/public/js"); ?>
  </body>
</html>