<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'email/Exception.php';
require 'email/PHPMailer.php';
require 'email/SMTP.php';

$nombre = $this->input->post('nombres');
$apellido = $this->input->post('apellidos');
$municipio = $this->input->post('municipio');
$direccion = $this->input->post('direccion');
$contacto = $this->input->post('contacto');
$email = $this->input->post('email');
$password = $this->input->post('password');
$image = $_FILES["File"];
$r='';
$destination=NULL;
$ok_image=true;
$new_name='';

$new_password = password_hash($password,PASSWORD_DEFAULT);
$data=['name'=>$nombre, 'apellidos'=>$apellido, 'municipio'=>$municipio, 'contacto'=>$contacto, 'email'=>$email, 'direccion'=>$direccion, 'rol'=>2, 'created_at'=>date('Y-m-d h:m:s'), 'password'=>$new_password];

if (!isset($image['tmp_name'])) {
	//valida q la imagen no tenga error
    if ($image['error']==0) {
        $orig_date = new DateTime();
       	$orig_date=$orig_date->getTimestamp();
       	$new_name = explode('.', $image['name']);
       	$new_name = $new_name[0].'_'.$orig_date.'.'.$new_name[1];
       	$destination ="/public_html/assets/img/clientes/".$new_name;
       	//sube la imagen al local
       	if (move_uploaded_file($image['tmp_name'], $destination)) {		
       		$data=array_merge($data, ['url_imagen'=>$new_name]);           		
       	}else{
       		$ok_image=false;
       		$r = @json_encode(array('res'=>'bad','msj'=>'Problemas subiendo la imagen.'));
       	}
    }else{
    	$ok_image=false;
    	$r = @json_encode(array('res'=>'bad','msj'=>'Problemas subiendo la imagen.'));
    }
}

if ($ok_image) {
    $query=$this->db->insert('users', $data);
	if ($query) {
		$r = @json_encode(array('res'=>'ok'));
	}else{
		$r = @json_encode(array('res'=>'bad','msj'=>'No se pudo actualizar los datos del técnico.'));
	}
}	        	

print "<script>parent.postMessage( '".$r."' , '".base_url()."')</script>"; 