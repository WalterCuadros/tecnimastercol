<!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right"></div>
      </div>
      <!--logo start-->
      <a href="<?=base_url()?>admin" class="logo"><b>Tecni <span>Master</span></b></a>
      <!--logo end-->
      
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><button class="logout">Cerrar Sesion</button></li>
        </ul>
      </div>
    </header>
    <!--header end-->