
 <!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=gb18030">     
  <title>Servicio tecnico lavadoras neveras aires Bucaramanga </title>
  <meta name="description" content="Mantenimiento y Reparación de Lavadoras, Neveras, Aires. Servicio técnico a domicilio especialistas en todas las marcas Bucaramanga, Floridablanca, Girón y Piedecuesta" />  
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url(); ?>washing-machine.png">
  <link rel="icon" type="image/png" href="<?php echo base_url(); ?>washing-machine.png">
  
  <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Muli:300,400" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/fonts/icomoon/style.css">

  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/web/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/web/jquery-ui.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/web/owl.carousel.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/web/owl.theme.default.min.css">

  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/web/jquery.fancybox.min.css">

  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/web/bootstrap-datepicker.css">

  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/web/aos.css">
  <link href="<?php echo base_url(); ?>assets/css/web/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/web/style.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/web/stilos.css">  

  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/web/themify-icons.css">
  <link href="<?php echo base_url(); ?>assets/css/web/styles.css" rel="stylesheet">
  <link href="<?=base_url()?>assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">